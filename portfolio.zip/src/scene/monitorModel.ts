import { MeshPhysicalMaterial } from 'three'
import type { Material, Mesh, MeshPhysicalMaterialParameters, Object3D } from 'three'
import { colors } from '../config/theme'

/**
 * public/models/white_mesh.glb is the monitor. Its geometry is used exactly as supplied: nothing here moves, rebuilds or
 * remeshes a vertex. The file was prepared once with smooth vertex normals and split into nine material groups (the same
 * triangles, only regrouped), named below. Everything is in the model's own units; the scene scale and placement are applied
 * by a wrapper group in Monitor.tsx, never to the mesh.
 *
 * Model space (measured on the file): +z is the rear (faces the visitor), -z the front/screen (faces the robot), +y up.
 *  - monitor_panel:        flat centre of the rear shell
 *  - monitor_bevel_*:      the four sloping bevels of the rear shell (top / side / bottom; both sides share one group)
 *  - monitor_side:         side wall of the casing, between the bevels and the front trim
 *  - monitor_trim:         narrow navy trim along the front edge of the wall, and the raised frame round the screen
 *  - monitor_screen:       the recessed flat front glass
 *  - monitor_stand:        neck, and the sides/underside of the base
 *  - monitor_base_top:     top face of the base plate
 * The PROJECTS lettering is not part of the mesh (the rear panel is perfectly flat), so Monitor.tsx lays it on as a separate plane.
 */

/** Names of the material groups inside white_mesh.glb. */
const PANEL = 'monitor_panel'
const BEVEL_TOP = 'monitor_bevel_top'
const BEVEL_SIDE = 'monitor_bevel_side'
const BEVEL_BOTTOM = 'monitor_bevel_bottom'
const SIDE = 'monitor_side'
const TRIM = 'monitor_trim'
const SCREEN = 'monitor_screen'
const STAND = 'monitor_stand'
const BASE_TOP = 'monitor_base_top'

/** Anchors measured on the GLB, in model units: casing centre x, underside of the base, front face of the casing, rear flat panel. */
const SRC = { centreX: -0.019519, baseY: -0.733481, frontZ: -0.081209, rearZ: 0.190830, panelCentreY: 0.077 } as const

/**
 * Uniform scale from the GLB's units to metres: 0.332 (the first fit, which put the casing centre where the original monitor's was)
 * times 1.15, so the casing reads 15% larger. The whole model is scaled as one, so the casing keeps its aspect and the base and neck
 * keep the original design's proportions. Casing 0.749 x 0.453 m; its centre rises to 0.319 m above the desk (about 4 cm higher),
 * its lower edge to 0.093 m.
 */
const SCALE = 0.332 * 1.15

export const MONITOR_MODEL = {
  scale: SCALE,
  /** Wrapper-group position: puts the model's origin on the desk under the casing centre, with the front of the casing at z = 0. */
  offset: [-SRC.centreX * SCALE, -SRC.baseY * SCALE, -SRC.frontZ * SCALE] as [number, number, number],
  /** Wrapper-space z of the rear flat panel, and the height of its visual centre (where the label sits). */
  rearPanelZ: (SRC.rearZ - SRC.frontZ) * SCALE,
  rearPanelCentreY: (SRC.panelCentreY - SRC.baseY) * SCALE,
}

/** Restrained PBR finishes: satin plastic, lightly coated navy, near-black glass. No sheen on the casing, so it never washes out to white. */
const SATIN = { roughness: 0.52, metalness: 0, clearcoat: 0.06, clearcoatRoughness: 0.55 } as const
const FINISH: Record<string, MeshPhysicalMaterialParameters> = {
  [PANEL]: { color: colors.monitorRear, ...SATIN },
  [BEVEL_TOP]: { color: colors.monitorBevelTop, ...SATIN },
  [BEVEL_SIDE]: { color: colors.monitorBevelSide, ...SATIN },
  [BEVEL_BOTTOM]: { color: colors.monitorBevelBottom, ...SATIN },
  [SIDE]: { color: colors.monitorSide, ...SATIN, roughness: 0.55 },
  [TRIM]: { color: colors.monitorTrim, roughness: 0.38, metalness: 0.18, clearcoat: 0.25, clearcoatRoughness: 0.35 },
  [SCREEN]: { color: colors.monitorScreen, roughness: 0.12, metalness: 0, clearcoat: 0.5, clearcoatRoughness: 0.1 },
  [STAND]: { color: colors.monitorStand, roughness: 0.45, metalness: 0.2, clearcoat: 0.15, clearcoatRoughness: 0.45 },
  [BASE_TOP]: { color: colors.monitorBaseTop, roughness: 0.5, metalness: 0.05, clearcoat: 0.04, clearcoatRoughness: 0.55 },
}

/**
 * A copy of the loaded model with the finishes above assigned by material name, and shadows set (the loader's cached scene,
 * its geometry and its placeholder materials are left untouched). The glass takes shadows but does not cast them.
 * The caller disposes the returned materials.
 */
export function prepareMonitor(root: Object3D): { model: Object3D; materials: MeshPhysicalMaterial[] } {
  const materials = new Map<string, MeshPhysicalMaterial>()
  const model = root.clone(true)
  model.traverse((o) => {
    const mesh = o as Mesh
    if (!mesh.isMesh) return
    const name = (mesh.material as Material).name
    const finish = FINISH[name]
    if (finish) {
      let mat = materials.get(name)
      if (!mat) { mat = new MeshPhysicalMaterial({ ...finish, name }); materials.set(name, mat) }
      mesh.material = mat
    }
    mesh.castShadow = name !== SCREEN
    mesh.receiveShadow = true
  })
  return { model, materials: [...materials.values()] }
}
